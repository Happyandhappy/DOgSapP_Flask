# here I was trying use the pattern shown in the python docs so that all views controllers from this package
# would be inserted during the `import` statement in `application.py`
# https://docs.python.org/3/tutorial/modules.html#importing-from-a-package
# __all__ = ['auth']